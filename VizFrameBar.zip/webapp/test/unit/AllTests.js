sap.ui.define([
	"VizFrameBar/VizFrameBar/test/unit/controller/View1.controller"
], function () {
	"use strict";
});