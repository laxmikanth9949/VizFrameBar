sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/mvc/Controller",
	"sap/viz/ui5/format/ChartFormatter",
	"sap/ui/model/json/JSONModel",
	"sap/viz/ui5/api/env/Format",
	"sap/viz/ui5/controls/Popover",
	"sap/m/MessageBox",
	"../model/InitPage"
], function (jQuery, Controller, ChartFormatter, JSONModel, Format,Popover, MessageBox, InitPageUtil) {
	"use strict";

	return Controller.extend("VizFrameBar.VizFrameBar.controller.View1", {
		//	dataPath : "https://webidetesting7734865-c5288613trial.dispatcher.hanatrial.ondemand.com/~1559900545000~/webapp/model/Data.json";
		dataPath: "model/Data.json",
		/*settingsModel: {
			dataset: {
				name: "Custom Popover",
				defaultSelected: 0,
				values: [{
					name: "Action Button",
					value: [{
						type: "action",
						text: "Actions",
						press: function () {
							sap.m.MessageBox.show('This is a callback function from "Action Button" Action.', {
								title: "Information",
								icon: "INFORMATION"
							});
						}
					}],
					popoverProps: null
				}, {
					name: "In-Place Navigation",
					value: [{
						type: "navigation",
						text: "Actions",
						children: [{
							text: "Action 1",
							press: function () {
								MessageBox.show('This is a callback function from "In-Place Navigation" Action1.', {
									title: "Information",
									icon: "INFORMATION"
								});
							}
						}, {
							text: "Action 2",
							press: function () {
								MessageBox.show('This is a callback function from "In-Place Navigation" Action2.', {
									title: "Information",
									icon: "INFORMATION"
								});
							}
						}, {
							text: "Action 3",
							press: function () {
								MessageBox.show('This is a callback function from "In-Place Navigation" Action3.', {
									title: "Information",
									icon: "INFORMATION"
								});
							}
						}]
					}],
					popoverProps: null
				}, {
					name: "Custom Content",
					value: null,
					popoverProps: {
						"customDataControl" : function (data) {
							if (data.data.val) {
								var exData = [{
									"Owner": "Brooks A. Williams",
									"Phone": "778-721-2235",
									"icon" : "new sap.m.Button()"
								}, {
									"Owner": "Candice C. Bernardi",
									"Phone": "204-651-2434",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Robert A. Cofield",
									"Phone": "262-684-6815",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Melissa S. Maciel",
									"Phone": "778-983-3365",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Diego C. Lawton",
									"Phone": "780-644-4957",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Anthony K. Evans",
									"Phone": "N/A",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Sue K. Gonzalez",
									"Phone": "647-746-4119",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Nancy J. Oneal",
									"Phone": "N/A",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Sirena C. Mack",
									"Phone": "905-983-3365",
									"icon" : new sap.m.Button()
								}, {
									"Owner": "Gloria K. Bowlby",
									"Phone": "N/A",
									"icon" : new sap.m.Button()
								}];
								var values = data.data.val,
									divStr = "",
									idx = values[1].value;
								var svg =
									"<svg width='10px' height='10px'><path d='M-5,-5L5,-5L5,5L-5,5Z' fill='#5cbae6' transform='translate(5,5)'></path></svg>";
								divStr = divStr + "<div style = 'margin: 15px 30px 0 10px'>" + svg + "<b style='margin-left:10px'>" + values[0].value +
									"</b></div>";
								divStr = divStr + "<div style = 'margin: 5px 30px 0 30px'>" + values[2].name + "<span style = 'float: right'>" + values[2].value +
									"</span></div>";
									//	divStr = divStr + "<div style = 'margin: 5px 30px 0 30px'>" + values[3].icon + "<span style = 'float: right'>" + values[3].value +
									//"</span></div>";
									
								divStr = divStr + "<div style = 'margin: 5px 30px 0 30px'>" + "Owner<span style = 'float: right'>" + exData[idx].Owner +
									"</span></div>";
								divStr = divStr + "<div style = 'margin: 5px 30px 15px 30px'>" + "Phone<span style = 'float: right'>" + exData[idx].Phone +
									"</span></div>";
									divStr = divStr + "<div style = 'margin: 5px 30px 15px 30px'>" + "icon<span style = 'float: right'>" + new sap.m.Button() +
									"</span></div>";
									
								return new sap.ui.core.HTML({
									content: divStr
								});
							}
							
						}
					}
					
				}]
			}
		},*/

		onInit: function () {
			//VizFrame1
				this.oModel = new sap.ui.model.json.JSONModel("model/Data.json");
				this.getView().byId("idVizFrame").setModel(this.oModel);
			var oVizFrame1 = this.getView().byId("idVizFrame1");
			
			//VizFrame2
			oVizFrame1.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					dataLabel: {
						showTotal: true
					}
				},
				tooltip: {
					visible: true
				},
				title: {
					text: "Stacked Bar Chart"
				}
			});
			var oDataset = new sap.viz.ui5.data.FlattenedDataset({
				dimensions: [{
					name: "Class1",
					value: "{Fruit}"
				}
				],

				measures: [{
					name: "Fruit",
					value: "{Class1}"
				}],

				data: {
					path: "/results"
				}
			});
			oVizFrame1.setDataset(oDataset);
			oVizFrame1.setModel(this.oModel);
			var oFeedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "categoryAxis",
				"type": "Dimension",
				"values": ["Class1"]
			});
			oVizFrame1.addFeed(oFeedCategoryAxis);
			
			oVizFrame1.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem({
				"uid": "color",
				"type": "Measure",
				"values": ["Class2"]
			}));
			
			oVizFrame1.addFeed(new sap.viz.ui5.controls.common.feeds.FeedItem({
					"uid": "valueAxis",
					"type": "Measure",
					"values": ["Fruit"]
				}));
			oVizFrame1.data({key :"Fruit"});
			Format.numericFormatter(ChartFormatter.getInstance());
			var formatPattern = ChartFormatter.DefaultPattern;
			// set explored app's demo model on this sample
			 var oModel = new JSONModel(this.settingsModel);
			 this.getView().setModel(oModel);
		//VizFrame1
			var oVizFrame = this.oVizFrame = this.getView().byId("idVizFrame");
			oVizFrame.setVizProperties({
				plotArea: {
					dataLabel: {
						formatString: formatPattern.SHORTFLOAT_MFD2,
						visible: true
					}
				},
				valueAxis: {
					label: {
						formatString: formatPattern.SHORTFLOAT
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				title: {
					visible: false
				}
			});
		/*	var dataModel = new JSONModel(this.dataPath);
			oVizFrame.setModel(dataModel);*/
			debugger;
			this.oPopOver1 = this.getView().byId("idPopOver1");
			this.oPopOver1.connect(oVizFrame1.getVizUid());
			this.oPopOver1.setActionItems([{
				type: "action",
				text: "Demo",
				press: function () {
					sap.m.MessageBox.show('This is a callback function from "Action Button" Action.');
				}
			}]);
			debugger;
			this.oPopOver = this.getView().byId("idPopOver");
			this.oPopOver.connect(oVizFrame.getVizUid());
			this.oPopOver.setActionItems([{
				type: "action",
				text: "Demo",
				press: function () {
					debugger;
					sap.m.MessageBox.show('This is a callback function from "Action Button" Action.');
				}
			}]);
			/*	var bindValue = this.settingsModel.dataset.values[1];
				this.oPopOver = new sap.viz.ui5.controls.Popover(bindValue.popoverProps);
				this.oPopOver.connect(this.oVizFrame.getVizUid());
				this.oPopOver.setActionItems(bindValue.value);*/
		//	this.oPopOver.setFormatString(formatPattern.STANDARDFLOAT);
		//	InitPageUtil.initPageSettings(this.getView());
		},
		
	/*	handleLinkPress: function(e) {
     var link = this.getView().byId("idVizFrame1");
     var oPopover = new sap.m.Popover({
         title: "Sample Popover",
         content: [new sap.m.Image({
             src: "https://www.google.co.in/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png",
             width: "150px"
         })],
         footer: [new sap.m.Button({
             text: "Click me!"
         })]
     });
     oPopover.openBy(link);
 },*/
		
		onAfterRendering: function () {
		/*	var datasetRadioGroup = this.getView().byId("datasetRadioGroup");
			datasetRadioGroup.setSelectedIndex(this.settingsModel.dataset.defaultSelected);*/
		}
	/*	onDatasetSelected: function (oEvent) {
			var datasetRadio = oEvent.getSource();
			if (this.oVizFrame && datasetRadio.getSelected()) {
				var bindValue = datasetRadio.getBindingContext().getObject();
				this.oPopOver = new sap.viz.ui5.controls.Popover(bindValue.popoverProps);
				this.oPopOver.connect(this.oVizFrame.getVizUid());
				this.oPopOver.setActionItems(bindValue.value);
			}
		}*/
	});
});